import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneCheckbox,
  PropertyPaneTextField,IPropertyPaneGroup
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'HomePageWebPartStrings';
import HomePage from './components/HomePage';
import { IHomePageProps } from './components/IHomePageProps';

export interface IHomePageWebPartProps {
  description: string;
  setPathHTML : any;
  absoluteURL : any;
  showPopUp : boolean;
  popupURL : any;
  setYoutubeURL: string;
  setYouTubeOn : boolean;
}

export default class HomePageWebPart extends BaseClientSideWebPart <IHomePageWebPartProps> {

  public render(): void {
    const element: React.ReactElement<IHomePageProps> = React.createElement(
      HomePage,
      {
        description: this.properties.description,
        setPathHTML : this.properties.setPathHTML,
        absoluteURL : this.context.pageContext.web.absoluteUrl,
        showPopUp : this.properties.showPopUp,
        popupURL: this.properties.popupURL,
        setYoutubeURL : this.properties.setYoutubeURL
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  //For the apply button
  protected get disableReactivePropertyChanges(): boolean {
    return true;
  }

  protected onAfterPropertyPaneChangesApplied(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
    this.render();
  }
  //For the apply button End

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {

    const showHideComponent: IPropertyPaneGroup["groupFields"] = [
      PropertyPaneCheckbox('showPopUp', {
        text: "Set popup box enable ?"
      })
     ]

     if(this.properties.showPopUp){
      showHideComponent.push(
            PropertyPaneTextField('popupURL', {
              label: "Set a path for Forms URL"
            })
         )
     }


     const showYouTubeChanel: IPropertyPaneGroup["groupFields"] = [
      PropertyPaneCheckbox('setYouTubeOn', {
        text: "Set YouTube enable ?"
      })
     ]

     if(this.properties.setYouTubeOn){
      showYouTubeChanel.push(
            PropertyPaneTextField('setYoutubeURL', {
              label: "Set a YouTube URL"
            })
         )
     }
    return {
      pages: [
        {
         
          groups: [
            {           
              groupFields: [
                PropertyPaneTextField('setPathHTML', {
                  label: "Set a path for the HTML file"
                })
              ]
            },
            {           
              groupFields: showHideComponent
            },
            {
              groupFields: showYouTubeChanel              
            }
          ]
        }
      ]
    };
  }
}
