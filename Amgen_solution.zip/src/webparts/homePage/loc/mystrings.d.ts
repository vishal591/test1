declare interface IHomePageWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'HomePageWebPartStrings' {
  const strings: IHomePageWebPartStrings;
  export = strings;
}
