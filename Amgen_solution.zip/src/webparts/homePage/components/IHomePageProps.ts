export interface IHomePageProps {
  description: string;
  setPathHTML : any;
  absoluteURL : any;
  showPopUp : boolean;
  popupURL : any;
  setYoutubeURL: string;
  setYouTubeOn : boolean;
}
