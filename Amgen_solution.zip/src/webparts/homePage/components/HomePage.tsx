import * as React from 'react';
import styles from './HomePage.module.scss';
import { IHomePageProps } from './IHomePageProps';
import { escape } from '@microsoft/sp-lodash-subset';
import {SPComponentLoader} from '@microsoft/sp-loader';
import * as jQuery from 'jquery';
import 'react-responsive-modal/styles.css';
import { Modal } from 'react-responsive-modal';
import { ProgressIndicator } from 'office-ui-fabric-react/lib/ProgressIndicator';


export interface HomeState
{
  extHTML : any;
  open : boolean;
  isContentLoad : boolean; 
  isLoading : boolean; 
}

export default class HomePage extends React.Component<IHomePageProps, HomeState > {
  constructor(props) {
    super(props);
    this.faviconIcon();
    this.state = {
      extHTML:"",
      open: false,
      isContentLoad : false,
      isLoading: true
    };
  }

/// get Data From HTML file 
public getDataFromHTML(file) {
  fetch(file)
    .then(res => res.text())
    .then(
      (result) => {
        this.setState({
          extHTML: result,
          isContentLoad : true,
          isLoading : false
        });
      },
      (error) => {
        this.setState({          
        });
      }
    )    
}

/// to set youtube chanel link from proprty panel
public setYouTubeURL = () => { 
  if(this.props.setYoutubeURL && this.state.isContentLoad){
    jQuery('.youtubeEmbed').attr('src', this.props.setYoutubeURL);
  }
}

///to bind favicon icon it will take png from site assets.
public faviconIcon = () => {
      let url: string = this.props.absoluteURL+"/SiteAssets/favicon.png";
      var link = document.querySelector("link[rel*='icon']") as HTMLElement || document.createElement('link') as HTMLElement;
      link.setAttribute('type', 'image/x-icon');
      link.setAttribute('rel', 'shortcut icon');
      link.setAttribute('href', url);
      document.getElementsByTagName('head')[0].appendChild(link);
}

///this is the event 
componentDidMount() {
    if(this.props.setPathHTML !== undefined && this.props.setPathHTML !== null && this.props.setPathHTML !== ""){
          this.getDataFromHTML(this.props.setPathHTML);
          setTimeout(() => {
            this.onOpenModel();
          }, 1200);
      }    
  }
///this event call when state update.
componentDidUpdate(){
    this.setYouTubeURL();
  }

///to open model popup from menu bar and footer section 
public onOpenModel = () => {
    let react = this;
    jQuery('.opePopUpBox').on('click', function(){
      react.setState({ open: true });
    })   
  }

///use to close the model
  public onCloseModal = () => {
    this.setState({ open: false });
  };


  //render method
  public render(): React.ReactElement<IHomePageProps> {
    const { open } = this.state;
    
    if(this.state.isLoading ){
      return(<ProgressIndicator label="Please wait..." />); 
    }
    return (
      <div className={styles.homePage}>
        {
          this.state.extHTML !== undefined && this.state.extHTML !== null && this.state.extHTML !=="" &&
         <div dangerouslySetInnerHTML={{__html: this.state.extHTML}}></div>
        }   
        {
        this.props.showPopUp &&
        <div className="menuPopUpOpner">
              <Modal closeOnOverlayClick={false}  open={open} onClose={this.onCloseModal} center>
                  <div className="divIframer" dangerouslySetInnerHTML={{__html:`<iframe class="iFrameForms" src= ${this.props.popupURL} frameborder= "0" marginwidth= "0" marginheight= "0" style= "border: none; max-width:100%; max-height:100vh" allowfullscreen webkitallowfullscreen mozallowfullscreen msallowfullscreen> </iframe>`}}></div>
              </Modal>
        </div>
        }
      </div>
    );
  }
}
